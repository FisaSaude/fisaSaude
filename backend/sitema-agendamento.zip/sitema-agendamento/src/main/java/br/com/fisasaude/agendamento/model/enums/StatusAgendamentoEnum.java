package br.com.fisasaude.agendamento.model.enums;

public enum StatusAgendamentoEnum {
    AGENDADO("Agendado"),
    CONFIRMADO("Confirmado pelo paciente"),
    CANCELADO("Cancelado"),
    CONCLUIDO("Concluído"),
    BLOQUEADO("Bloqueado");

    private final String descricao;

    StatusAgendamentoEnum(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}

